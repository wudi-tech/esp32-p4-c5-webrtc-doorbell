# Acrylic Plate Manufacturing Package V2

## Vendor instructions

- Primary cut file: acrylic_plate_cut_v2.dxf
- Units: millimetres
- Geometry scale: 1:1
- Material: 5 mm clear cast PMMA
- Finished size: 220 x 190 mm
- Outer corner radius: R10
- Outline tolerance: +/- 0.20 mm
- Hole tolerance: +/- 0.10 mm
- Do not scale or mirror the DXF.
- Deburr all holes and edges.
- Keep the protective film until final assembly.
- Confirm the annotated PDF before production.

## Files

- acrylic_plate_cut_v2.dxf - authoritative cut geometry only
- acrylic_plate_reference_v2.svg - front/rear module placement reference
- acrylic_plate_manufacturing_drawing_v2.pdf - dimensions, hole schedule, and assembly notes

## Critical orientation

Coordinates use the front view with the origin at the lower-left corner. The rear power-board coordinates are still defined from this front-view datum. The camera remains directly below the CSI connector, and the LD2450 radar is vertical with its notch upward.

## 厂家说明

加工文件单位为毫米、比例为 1:1。材料为 5 mm 透明浇铸亚克力，成品外形 220 x 190 mm、外角 R10。不得缩放或镜像 DXF。孔口与边缘去毛刺，并保留保护膜。加工前请对照 PDF 确认外形、孔径和孔组。
